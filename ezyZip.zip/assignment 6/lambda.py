# 4. wap to check if a value is present in the list or not using lambda function

