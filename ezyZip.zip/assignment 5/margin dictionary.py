# 1.wap to input two dictionaries and the print the values by margin the two dictionaries. Hint: the update method()
personal = {
"name": "ram",
"age": 18,
"language": "Python"
}

personal.update({"role": "software engineer"})

print(personal)