import math
print('enter the coeffiencients of a quadratic equation')
a=int(input('enter the value of a'))
b=int(input('enter the value of b'))
c=int(input('enter the value of c'))
d=(b**2) - 4*a*c/2*a
x1=(-b + (d**0.5))
x2=(-b - (d**0.5))
print(x1)
print(x2)