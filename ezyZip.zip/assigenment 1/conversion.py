st = int(input("enter an integer:"))
print("Binary number",bin(st))
print("Octal number",oct(st))
print("Hexadecimal number",hex(st))