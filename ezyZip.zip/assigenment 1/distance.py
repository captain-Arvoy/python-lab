
meters = float(input("Enter distance in meters: "))
kilometers = meters / 1000
print("KM:",kilometers)
