
ft = float(input("Enter temperature in Fahrenheit: "))
ct = (ft - 32) * 5/9
print(ct)
