import math
x=int(input("Enter the number : "))
result = math.factorial(x)
print(result)